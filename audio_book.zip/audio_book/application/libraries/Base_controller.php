<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Base_controller extends CI_Controller {
	public function index()
	{
        
	}

    public function loadViews($dataUrl = "", $data = NULL){
        $this->load->view('common/header');
        $this->load->view('common/menu');
        $this->load->view($dataUrl, $data);
		$this->load->view('common/footer');
    }

    public function loadLoginView($dataUrl){        
        $this->load->view($dataUrl);		
    }

    function isLoggedIn()
	{
		$isLoggedIn = $this->session->userdata ( 'isLoggedIn' );
		
		if (! isset ( $isLoggedIn ) || $isLoggedIn != TRUE)
		{
			redirect ( 'login' );
		} 
		else
		{
			// $this->role = $this->session->userdata ( 'role' );
			// $this->vendorId = $this->session->userdata ( 'userId' );
			// $this->name = $this->session->userdata ( 'name' );
			// $this->roleText = $this->session->userdata ( 'roleText' );
			// $this->lastLogin = $this->session->userdata ( 'lastLogin' );
			
			// $this->global ['name'] = $this->name;
			// $this->global ['role'] = $this->role;
			// $this->global ['role_text'] = $this->roleText;
			// $this->global ['last_login'] = $this->lastLogin;
		}
	}

    
}
