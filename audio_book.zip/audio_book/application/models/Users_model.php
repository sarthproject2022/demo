<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users_model extends CI_Model {   
    public function __construct(){
        parent::__construct();
    }

    var $table = 'ss_users';         
    var $column_order = array(null,'p1.userId','p1.name','p1.emailId','p1.phoneNo','p2.roleName','p1.status','p1.createdOn');
    var $column_search = array('p1.userId','p1.name','p1.emailId','p1.phoneNo','p2.roleName'); 
    var $order = array('p1.userId' => 'desc');
 
    private function _get_datatables_query_data()
    {          
        $this->db->select('p1.userId , p1.name, p1.emailId, p1.phoneNo, p2.roleName, p1.status, p1.createdOn');
        $this->db->from('ss_users as p1');
        $this->db->join('ss_roles as p2','p2.roleId = p1.roleId');
        $this->db->where('p1.isDeleted',1);             
        
        $i = 0;
        foreach ($this->column_search as $item) 
        {
            if($_POST['search']['value']) 
            {                 
                if($i===0) 
                {
                    $this->db->group_start(); 
                    $this->db->like($item, $_POST['search']['value']);
                }
                else
                {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
 
                if(count($this->column_search) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
         
        if(isset($_POST['order']))
        {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } 
        else if(isset($this->order))
        {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }
 
    public function get_datatable_data()
    {
        $this->_get_datatables_query_data();
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }
 
    public function count_filtered_data()
    {
        $this->_get_datatables_query_data();
        $query = $this->db->get();
        return $query->num_rows();
    }
 
    public function count_all_data()
    {
        $this->db->from($this->table);
        $this->db->where('isDeleted',1);
        return $this->db->count_all_results();
    }

    public function saveUser($data){
        $this->db->insert($this->table,$data);
        return $this->db->insert_id();
    }

    public function getUsersData($userId){
        $this->db->select('userId, name, emailId, password, phoneNo, roleId');
        $this->db->from('ss_users');        
        $this->db->where('userId',$userId);  
        $query = $this->db->get();
        return $query->row();
    }

    public function updateUser($userId, $data)
    {        
        $this->db->where('userId', $userId);
        $this->db->update($this->table, $data);        
        return $this->db->affected_rows();
    }

    public function deleteUserById($userId){
        $data = array( 
            'isDeleted' => 0
        );
        $this->db->where('userId', $userId);
        $this->db->update($this->table,$data);
    }

    public function update_status($userId,$status)
    {
        $data['status'] = $status;
        $this->db->where('userId', $userId);
        $this->db->update($this->table, $data);
    } 
}
?>