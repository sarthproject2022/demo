<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Content_model extends CI_Model {   
    public function __construct(){
        parent::__construct();
    }

    var $table = 'ss_content';         
    var $column_order = array(null,'p2.categoryName', 'p3.subCategoryName', 'p1.title', 'p1.subTitle', 'p1.contentType', 'p1.playOrder', 'p1.contentImage', 'p1.accessValue','p1.status');
    var $column_search = array('p2.categoryName', 'p3.subCategoryName', 'p1.title', 'p1.subTitle', 'p1.description', 'p1.contentType', 'p1.playOrder', 'p1.contentImage', 'p1.accessValue', 'p1.nameOnDisk'); 
    var $order = array('p1.contentId' => 'desc');
 
    private function _get_datatables_query_data()
    {          
        $this->db->select('p1.contentId, p1.title, p1.subTitle, p1.description, p1.contentType, p1.playOrder, p1.contentImage, p1.accessValue, p1.nameOnDisk, p1.status, p2.categoryName, p2.categoryId, p3.subCategoryId, p3.subCategoryName');
        $this->db->from('ss_content as p1');
        $this->db->join('ss_category as p2','p2.categoryId = p1.categoryId');
        $this->db->join('ss_sub_category as p3','p3.subCategoryId = p1.subCategoryId');
        $this->db->where('p1.isDeleted',1);             
        
        $i = 0;
        foreach ($this->column_search as $item) 
        {
            if($_POST['search']['value']) 
            {                 
                if($i===0) 
                {
                    $this->db->group_start(); 
                    $this->db->like($item, $_POST['search']['value']);
                }
                else
                {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
 
                if(count($this->column_search) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
         
        if(isset($_POST['order']))
        {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } 
        else if(isset($this->order))
        {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }
 
    public function get_datatable_data()
    {
        $this->_get_datatables_query_data();
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }
 
    public function count_filtered_data()
    {
        $this->_get_datatables_query_data();
        $query = $this->db->get();
        return $query->num_rows();
    }
 
    public function count_all_data()
    {
        $this->db->from($this->table);
        $this->db->where('isDeleted',1);
        return $this->db->count_all_results();
    }

    public function saveContentData($data){
        $this->db->insert($this->table,$data);
        return $this->db->insert_id();
    }

    public function getCategoryData($contentId){
        $this->db->select('p1.contentId, p1.title, p1.subTitle, p1.description, p1.contentType, p1.playOrder, p1.contentImage, p1.accessValue, p1.nameOnDisk, p1.status, p2.categoryName, p2.categoryId, p3.subCategoryId, p3.subCategoryName');
        $this->db->from('ss_content as p1');
        $this->db->join('ss_category as p2','p2.categoryId = p1.categoryId');
        $this->db->join('ss_sub_category as p2','p2.subCategoryId = p1.subCategoryId');             
        $this->db->where('p1.contentId',$contentId);  
        $query = $this->db->get();
        return $query->row();
    }

    public function updatecontent($contentId, $data)
    {        
        $this->db->where('contentId', $contentId);
        $this->db->update($this->table, $data);        
        return $this->db->affected_rows();
    }

    public function deletecontentById($contentId){
        $data = array( 
            'isDeleted' => 0
        );
        $this->db->where('contentId', $contentId);
        $this->db->update($this->table,$data);
    }

    public function update_status($contentId,$status)
    {
        $data['status'] = $status;
        $this->db->where('contentId', $contentId);
        $this->db->update($this->table, $data);
    } 

    public function getAllCategory(){
        $this->db->select('categoryId, categoryName');
        $this->db->from('ss_category');        
        $this->db->where('status',1);  
        $this->db->where('isDeleted',1);  
        $query = $this->db->get();
        return $query->result();
    }

    public function getAllSubCategory($categoryId){
        $this->db->select('subCategoryId, subCategoryName');
        $this->db->from('ss_sub_category');        
        $this->db->where('categoryId',$categoryId);  
        $this->db->where('status',1);  
        $this->db->where('isDeleted',1);  
        $query = $this->db->get();
        return $query->result();
    }
}
?>