<?php
class Login_model extends CI_Model {   

    public function check_login($emailId, $password){
        $where = array('emailId'=>$emailId, 'password'=>$password, 'status'=>'1', 'isDeleted'=>'1');
        $this->db->select('userId, name, emailId, password, phoneNo, roleId , status');
        $this->db->from('ss_users');
        $this->db->where($where);        
        $result = $this->db->get();
        $user = $result->row();
        
        if(!empty($user)){            
            return $user;            
        } else {
            return array();
        }
    }

    public function saveLoginDetails($data){
        $this->db->insert('ss_last_admin_login',$data);
        return $this->db->insert_id();
    }
}