<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include APPPATH.'libraries/Base_controller.php';

class Home extends Base_controller {
	public function index()
	{
        // $this->load->view('common/header');
        // $this->load->view('common/menu');
        // $this->load->view('home');
		// $this->load->view('common/footer');
        $this->loadViews('home');
	}

    public function form_advanced(){
        $this->loadViews('demo/form_advanced');
    }

    public function form_elements(){
        $this->loadViews('demo/form_elements');
    }

    public function form_editors(){
        $this->loadViews('demo/form_editors');
    }

    public function form_file_upload(){
        $this->loadViews('demo/form_file_upload');
    }

    public function form_validations(){
        $this->loadViews('demo/form_validations');
    }

    public function form_wizard(){
        $this->loadViews('demo/form_wizard');
    }

    public function page_register(){
        $this->loadViews('demo/page_register');
    }

    public function page_register2(){
        $this->loadViews('demo/page_register2');
    }

    public function basic_tables(){
        $this->loadViews('demo/basic_tables');
    }

    public function data_tables(){
        $this->loadViews('demo/data_tables');
    }

    public function ui_embed_video(){
        $this->loadViews('demo/ui_embed_video');
    }

    public function ui_modals(){
        $this->loadViews('demo/ui_modals');
    }

    public function ui_spinners(){
        $this->loadViews('demo/ui_spinners');
    }

    public function ui_breadcrumb(){
        $this->loadViews('demo/ui_breadcrumb');
    }

}
