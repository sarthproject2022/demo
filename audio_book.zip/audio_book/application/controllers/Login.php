<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include APPPATH.'libraries/Base_controller.php';

class Login extends Base_controller {

    public function __construct()
	{
        parent::__construct();	   
     	$this->load->model('login_model');		 
    }

	public function index(){        
        $this->isLoggedIn();
	}

    function isLoggedIn()
    {
        $isLoggedIn = $this->session->userdata('isLoggedIn');
        
        if(!isset($isLoggedIn) || $isLoggedIn != TRUE)
        {           
            $this->loadLoginView('login');
        }
        else
        {
            redirect ('home');
        }
    }

    public function check_login(){   

        $this->form_validation->set_rules('emailaddress', 'Email', 'required|trim');
        $this->form_validation->set_rules('password', 'Password', 'required|max_length[16]');        
        
        if($this->form_validation->run() == FALSE)
        {           
            $this->index();
        }
        else
        {
            $emailId = $_POST['emailaddress'];
            $password = $_POST['password'];

            $get_user_details = $this->login_model->check_login($emailId, $password);           

            if(!empty($get_user_details)){                
                $loginDetails = array(
                    "userId" => $get_user_details->userId,
                    "uname" => $get_user_details->name,                    
                    "machineIp" => $_SERVER['REMOTE_ADDR'], 
                    "userAgent" => '', 
                    "agentString" => '', 
                    "platform" => '',
                    'loginOn' => date('Y-m-d')
                );
               
                $saveLogin = $this->login_model->saveLoginDetails($loginDetails);

                $saveSession = array(
                    'userId' => $get_user_details->userId,
                    'fullname' => $get_user_details->name,
                    'emailId' => $get_user_details->emailId,
                    'phoneNo' => $get_user_details->phoneNo,
                    'roleId' => $get_user_details->roleId,
                    'isLoggedIn' => TRUE                
                );

                $this->session->set_userdata($saveSession);

                redirect('home');                

            }else{                               
                $this->session->set_flashdata('error', 'Username or password mismatch');
                $this->index();
            }
        }
    }

    function logout() {
		$this->session->sess_destroy();		
		redirect ('login');
	}
}
?>