<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include APPPATH.'libraries/Base_controller.php';

class Category extends Base_controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('category_model');
        $this->isLoggedIn();        
    }

	public function index()
	{
        $this->loadViews('category/list_category');
	}

    public function listData(){

        $getList = $this->category_model->get_datatable_data(); 
        $data = array();
        $no = $_POST['start'];
        
        // print_r($getList);exit;
        foreach ($getList as $row_data)
        {
            $no++;
            $row = array();
            $edit_category = base_url().'category/getCategoryData/'.$row_data->categoryId;
            $image = base_url().'uploads/category/'.$row_data->categoryImage;

            $row[] = $no;
            $row[] = $row_data->categoryName;            
            $row[] = '<a href="'.$image.'" download><img src="'.$image.'" width="50"  /></a>';
            $row[] = $row_data->categoryOrder;                   
                        
            if($row_data->status == 1)
                $status_class = "btn btn-success";
            else if($row_data->status == 0)
                $status_class = "btn btn-danger";    

            $status = ($row_data->status? "Active" : "Inactive");
            $row[] = '<i data='."'".$row_data->categoryId."'".' class="status_checks '.$status_class.'">'.$status.'</i>';
            
            $row[] = '
                    <a href="'.$edit_category.'" class="" title="update"><i class="material-icons">edit</i></a>                    
                    <a href="javascript:void(0)" class="" onclick="deleteCategory('."'".$row_data->categoryId."'".')" title="delete"><i class="material-icons">delete</i></a>
                ';           
                // <a href="javascript:void(0)" class="" title="view"><i class="material-icons">&#xE8F4;</i></a>
            $data[] = $row;
        }
 
        $output = array(
                "draw" => $_POST['draw'],
                "recordsTotal" => $this->category_model->count_all_data(),
                "recordsFiltered" => $this->category_model->count_filtered_data(),
                "data" => $data,
            );        
        echo json_encode($output);
    }

    public function addNewCategory(){
        $this->loadViews('category/add_category');
    }

    public function getCategoryData($categoryId){
        // print_r($categoryId);
        $data['categoryData'] = $this->category_model->getCategoryData($categoryId);   
        // print_r($data['categoryData']); exit;
        $this->loadViews('category/edit_category',$data);
    }

    public function saveCategory(){
        // print_r($_POST);exit;
        $categoryName = $this->input->post('categoryName');        
        $categoryOrder = $this->input->post('categoryOrder');

        $config=array(
            'upload_path'=>'uploads/category/',
            'allowed_types'=>'jpg|jpeg|png',
            'file_name'=>rand(1,999999),
            'max_size'=>0
        );
        $this->load->library('upload', $config);
        $this->upload->initialize($config);            

        if($_FILES['categoryImage']['name']!='')
        {
            if($this->upload->do_upload('categoryImage'))
            {
                $dt = $this->upload->data();
                $_POST['categoryImage'] = $dt['file_name'];
            }
        }else{
            $_POST['categoryImage'] = "";
        }

        $data = array(
            'categoryName' => $categoryName,
            'categoryImage' => $_POST['categoryImage'],
            'categoryOrder' => $categoryOrder,            
            'createdBy' => $this->session->userdata('userId')
        );

        $last_insert = $this->category_model->saveCategory($data);
        echo json_encode($last_insert);
    }

    public function updatecategory(){
        // print_r($_POST);exit;
        $categoryId = $this->input->post('categoryId');
        $categoryName = $this->input->post('categoryName');        
        $categoryOrder = $this->input->post('categoryOrder');

        $config=array(
            'upload_path'=>'uploads/category/',
            'allowed_types'=>'jpg|jpeg|png',
            'file_name'=>rand(1,999999),
            'max_size'=>0
        );
        $this->load->library('upload', $config);
        $this->upload->initialize($config); 			

        if($_FILES['categoryImage']['name']!='')
        {
            if($this->upload->do_upload('categoryImage'))
            {
                $dt=$this->upload->data();
                $_POST['categoryImage']=$dt['file_name'];
            }else{
                $_POST['categoryImage'] = $_POST['old_categoryImage'];
                $data['error']=$this->upload->display_errors();
            }
        }else{
            $_POST['categoryImage'] = $_POST['old_categoryImage'];
        }

        $data = array(
            'categoryName' => $categoryName,
            'categoryImage' => $_POST['categoryImage'],
            'categoryOrder' => $categoryOrder,     
            'updatedBy' => $this->session->userdata('userId'),
            'updatedOn' => date("Y-m-d h:i:s")
        );

        $last_update = $this->category_model->updatecategory($categoryId,$data);
        echo json_encode($last_update);
    }

    public function deleteCategory(){
        $categoryId = $this->input->post('categoryId');
        $this->category_model->deleteCategoryById($categoryId);
        echo json_encode(array("status" => TRUE));
    }

    public function update_status(){
        $this->category_model->update_status($this->input->post('categoryId'), $this->input->post('status'));
    }
    
}

?>