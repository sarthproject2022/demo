<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include APPPATH.'libraries/Base_controller.php';

class Subcategory extends Base_controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('subcategory_model');
        $this->isLoggedIn();        
    }

	public function index()
	{
        $this->loadViews('subcategory/list_subcategory');
	}

    public function listData(){

        $getList = $this->subcategory_model->get_datatable_data(); 
        $data = array();
        $no = $_POST['start'];
        
        // print_r($getList);exit;
        foreach ($getList as $row_data)
        {
            $no++;
            $row = array();
            $edit_category = base_url().'subcategory/getCategoryData/'.$row_data->subCategoryId;
            $image = base_url().'uploads/subcategory/'.$row_data->subCategoryImage;

            $row[] = $no;  
            $row[] = $row_data->categoryName;   
            $row[] = $row_data->subCategoryName;            
            $row[] = '<a href="'.$image.'" download><img src="'.$image.'" width="50"  /></a>';
            $row[] = $row_data->subCategoryOrder;                   
                        
            if($row_data->status == 1)
                $status_class = "btn btn-success";
            else if($row_data->status == 0)
                $status_class = "btn btn-danger";    

            $status = ($row_data->status? "Active" : "Inactive");
            $row[] = '<i data='."'".$row_data->subCategoryId."'".' class="status_checks '.$status_class.'">'.$status.'</i>';
            
            $row[] = '
                    <a href="'.$edit_category.'" class="" title="update"><i class="material-icons">edit</i></a>                    
                    <a href="javascript:void(0)" class="" onclick="deleteCategory('."'".$row_data->subCategoryId."'".')" title="delete"><i class="material-icons">delete</i></a>
                ';           
                // <a href="javascript:void(0)" class="" title="view"><i class="material-icons">&#xE8F4;</i></a>
            $data[] = $row;
        }
 
        $output = array(
                "draw" => $_POST['draw'],
                "recordsTotal" => $this->subcategory_model->count_all_data(),
                "recordsFiltered" => $this->subcategory_model->count_filtered_data(),
                "data" => $data,
            );        
        echo json_encode($output);
    }

    public function addsubcategory(){
        $data['categoryList'] = $this->subcategory_model->getAllCategory();
        $this->loadViews('subcategory/add_subcategory',$data);
    }

    public function getCategoryData($subCategoryId){        
        $data['categoryList'] = $this->subcategory_model->getAllCategory();
        $data['categoryData'] = $this->subcategory_model->getCategoryData($subCategoryId);           
        $this->loadViews('subcategory/edit_subcategory',$data);
    }

    public function saveCategory(){
        // print_r($_POST);exit;
        $categoryId = $this->input->post('categoryId');        
        $subCategoryName = $this->input->post('subCategoryName');        
        $subCategoryOrder = $this->input->post('subCategoryOrder');

        $config=array(
            'upload_path'=>'uploads/subcategory/',
            'allowed_types'=>'jpg|jpeg|png',
            'file_name'=>rand(1,999999),
            'max_size'=>0
        );
        $this->load->library('upload', $config);
        $this->upload->initialize($config);            

        if($_FILES['subCategoryImage']['name']!='')
        {
            if($this->upload->do_upload('subCategoryImage'))
            {
                $dt = $this->upload->data();
                $_POST['subCategoryImage'] = $dt['file_name'];
            }
        }else{
            $_POST['subCategoryImage'] = "";
        }

        $data = array(
            'categoryId' => $categoryId,
            'subCategoryName' => $subCategoryName,
            'subCategoryImage' => $_POST['subCategoryImage'],
            'subCategoryOrder' => $subCategoryOrder,            
            'createdBy' => $this->session->userdata('userId')
        );

        $last_insert = $this->subcategory_model->saveCategory($data);
        echo json_encode($last_insert);
    }

    public function updatecategory(){
        // print_r($_POST);exit;
        $categoryId = $this->input->post('categoryId'); 
        $subCategoryId = $this->input->post('subCategoryId');
        $subCategoryName = $this->input->post('subCategoryName');        
        $subCategoryOrder = $this->input->post('subCategoryOrder');

        $config=array(
            'upload_path'=>'uploads/subcategory/',
            'allowed_types'=>'jpg|jpeg|png',
            'file_name'=>rand(1,999999),
            'max_size'=>0
        );
        $this->load->library('upload', $config);
        $this->upload->initialize($config); 			

        if($_FILES['subCategoryImage']['name']!='')
        {
            if($this->upload->do_upload('subCategoryImage'))
            {
                $dt=$this->upload->data();
                $_POST['subCategoryImage']=$dt['file_name'];
            }else{
                $_POST['subCategoryImage'] = $_POST['old_subCategoryImage'];
                $data['error']=$this->upload->display_errors();

            }
        }else{
            $_POST['subCategoryImage'] = $_POST['old_subCategoryImage'];
        }

        $data = array(
            'categoryId' => $categoryId,
            'subCategoryName' => $subCategoryName,
            'subCategoryImage' => $_POST['subCategoryImage'],
            'subCategoryOrder' => $subCategoryOrder,     
            'updatedBy' => $this->session->userdata('userId'),
            'updatedOn' => date("Y-m-d h:i:s")
        );

        $last_update = $this->subcategory_model->updatecategory($subCategoryId,$data);
        echo json_encode($last_update);
    }

    public function deleteCategory(){
        $subCategoryId = $this->input->post('subCategoryId');
        $this->subcategory_model->deleteCategoryById($subCategoryId);
        echo json_encode(array("status" => TRUE));
    }

    public function update_status(){
        $this->subcategory_model->update_status($this->input->post('subCategoryId'), $this->input->post('status'));
    }
    
}

?>