<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include APPPATH.'libraries/Base_controller.php';

class Users extends Base_controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('users_model');
        $this->isLoggedIn();        
    }

	public function index()
	{        
        $this->loadViews('user/list_user');
	}

    public function listData(){

        $getList = $this->users_model->get_datatable_data(); 
        $data = array();
        $no = $_POST['start'];
        
        // print_r($getList);exit;
        foreach ($getList as $row_data)
        {
            $no++;
            $row = array();
            $edit_user = base_url().'users/getUsersData/'.$row_data->userId;

            $row[] = $no;            
            $row[] = $row_data->name;
            $row[] = $row_data->emailId;
            $row[] = $row_data->phoneNo;
            $row[] = $row_data->roleName;                        
            $row[] = $row_data->createdOn;            
                        
            if($row_data->status == 1)
                $status_class = "btn btn-success";
            else if($row_data->status == 0)
                $status_class = "btn btn-danger";    

            $status = ($row_data->status? "Active" : "Inactive");
            $row[] = '<i data='."'".$row_data->userId."'".' class="status_checks '.$status_class.'">'.$status.'</i>';
            
            $row[] = '
                    <a href="'.$edit_user.'" class="" title="update"><i class="material-icons">edit</i></a>                    
                    <a href="javascript:void(0)" class="" onclick="deleteUser('."'".$row_data->userId."'".')" title="delete"><i class="material-icons">delete</i></a>
                ';           
                // <a href="javascript:void(0)" class="" title="view"><i class="material-icons">&#xE8F4;</i></a>
            $data[] = $row;
        }
 
        $output = array(
                "draw" => $_POST['draw'],
                "recordsTotal" => $this->users_model->count_all_data(),
                "recordsFiltered" => $this->users_model->count_filtered_data(),
                "data" => $data,
            );        
        echo json_encode($output);
    }

    public function addNewUser(){

        //roles
        $this->loadViews('user/add_user');
    }

    public function getUsersData($userId){
        // print_r($userId);
        $data['userData'] = $this->users_model->getUsersData($userId);   
        // print_r($data['userData']); exit;
        $this->loadViews('user/edit_user',$data);
    }

    public function saveUser(){
        // print_r($_POST);exit;
        $name = $this->input->post('name');
        $emailId = $this->input->post('emailId');
        $phoneNo = $this->input->post('phoneNo');
        $password = $this->input->post('password');
        $roleId = $this->input->post('roleId');

        $data = array(
            'name' => $name,
            'emailId' => $emailId,
            'phoneNo' => $phoneNo,
            'password' => $password,
            'roleId' => $roleId,
            'createdBy' => $this->session->userdata('userId')
        );

        $last_insert = $this->users_model->saveUser($data);
        echo json_encode($last_insert);
    }

    public function updateUser(){
        // print_r($_POST);exit;
        $userId = $this->input->post('userId');
        $name = $this->input->post('name');
        $emailId = $this->input->post('emailId');
        $phoneNo = $this->input->post('phoneNo');
        $password = $this->input->post('password');
        $roleId = $this->input->post('roleId');

        $data = array(
            'name' => $name,
            'emailId' => $emailId,
            'phoneNo' => $phoneNo,
            'password' => $password,
            'roleId' => $roleId,
            'updatedBy' => $this->session->userdata('userId')
        );

        $last_update = $this->users_model->updateUser($userId,$data);
        echo json_encode($last_update);
    }

    public function deleteUser(){
        $userId = $this->input->post('userId');
        $this->users_model->deleteUserById($userId);
        echo json_encode(array("status" => TRUE));
    }

    public function update_status(){
        $this->users_model->update_status($this->input->post('userId'), $this->input->post('status'));
    }
    
}

?>