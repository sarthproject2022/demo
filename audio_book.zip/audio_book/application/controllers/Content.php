<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include APPPATH.'libraries/Base_controller.php';

class Content extends Base_controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('content_model');
        $this->isLoggedIn();        
    }

	public function index()
	{
        $this->loadViews('content/list_content');
	}

    public function listData(){

        $getList = $this->content_model->get_datatable_data(); 
        $data = array();
        $no = $_POST['start'];
        
        // print_r($getList);exit;
        foreach ($getList as $row_data)
        {
            $no++;
            $row = array();
            $edit_category = base_url().'content/getCategoryData/'.$row_data->contentId;
            $image = base_url().'uploads/contentImage/'.$row_data->contentImage;
            $audio = base_url().'uploads/contentData/'.$row_data->nameOnDisk;

            $contentType = "Video";
            if($row_data->contentType == 1){
                $contentType = "Audio";
            }else if($row_data->contentType == 2){
                $contentType = "Document";
            }

            $accessValue = "Free";
            if($row_data->accessValue == 1){
                $accessValue = "Free";
            }else if($row_data->accessValue == 2){
                $accessValue = "Basic";
            }else{
                $accessValue = "Prime";
            }

            $row[] = $no;  
            $row[] = $row_data->categoryName;   
            $row[] = $row_data->subCategoryName;            
            $row[] = $row_data->title;            
            $row[] = $row_data->subTitle;            
            $row[] = $contentType;                        
            $row[] = $accessValue;            
            $row[] = $row_data->playOrder; 
            $row[] = '<a href="'.$image.'" download><img src="'.$image.'" width="50"  /></a>';
            $row[] = '';            

            if($row_data->status == 1)
                $status_class = "btn btn-success";
            else if($row_data->status == 0)
                $status_class = "btn btn-danger";    

            $status = ($row_data->status? "Active" : "Inactive");
            $row[] = '<i data='."'".$row_data->contentId."'".' class="status_checks '.$status_class.'">'.$status.'</i>';
            
            $row[] = '
                    <a href="'.$edit_category.'" class="" title="update"><i class="material-icons">edit</i></a>                    
                    <a href="javascript:void(0)" class="" onclick="deletecontent('."'".$row_data->contentId."'".')" title="delete"><i class="material-icons">delete</i></a>
                ';           
                // <a href="javascript:void(0)" class="" title="view"><i class="material-icons">&#xE8F4;</i></a>
            $data[] = $row;
        }
 
        $output = array(
                "draw" => $_POST['draw'],
                "recordsTotal" => $this->content_model->count_all_data(),
                "recordsFiltered" => $this->content_model->count_filtered_data(),
                "data" => $data,
            );        
        echo json_encode($output);
    }

    public function addcontent(){
        $data['categoryList'] = $this->content_model->getAllCategory();
        $this->loadViews('content/add_content',$data);
    }

    public function getCategoryData($contentId){        
        $data['categoryList'] = $this->content_model->getAllCategory();
        $data['categoryData'] = $this->content_model->getCategoryData($contentId);           
        $this->loadViews('content/edit_content',$data);
    }

    public function saveContentData(){
        // print_r($_POST);print_r($_FILES);exit;
        $categoryId = $this->input->post('categoryId');        
        $subCategoryId = $this->input->post('subCategoryId');        
        $title = $this->input->post('title');        
        $subTitle = $this->input->post('subTitle');
        $description = $this->input->post('description');
        $contentType = $this->input->post('contentType');
        $accessValue = $this->input->post('accessValue');
        $playOrder = $this->input->post('playOrder');        


        $config = array(
            'upload_path' => 'uploads/contentImage/',
            'allowed_types' => 'jpg|jpeg|png',
            'file_name' => rand(1,999999),
            'max_size' => 0
        );
        $this->load->library('upload', $config);
        $this->upload->initialize($config);            

        if($_FILES['contentImage']['name']!='')
        {
            if($this->upload->do_upload('contentImage'))
            {
                $dt = $this->upload->data();
                $_POST['contentImage'] = $dt['file_name'];
            }
        }else{
            $_POST['contentImage'] = "";
        }

        $config1 = array(
            'upload_path' => 'uploads/contentData/',
            'allowed_types' => 'mp3|mp4',
            'file_name' => rand(1,999999),
            'max_size' => 0
        );
        $this->load->library('upload', $config1);
        $this->upload->initialize($config1);            

        if($_FILES['nameOnDisk']['name']!='')
        {
            if($this->upload->do_upload('nameOnDisk'))
            {
                $dt1 = $this->upload->data();
                $_POST['nameOnDisk'] = $dt1['file_name'];
            }
        }else{
            $_POST['nameOnDisk'] = "";
        }

        $data = array(
            'categoryId' => $categoryId,
            'subCategoryId' => $subCategoryId,
            'title' => $title,
            'subTitle' => $subTitle,
            'description' => $description,
            'contentType' => $contentType,
            'accessValue' => $accessValue,
            'playOrder' => $playOrder,
            'contentImage' => $_POST['contentImage'],
            'nameOnDisk' => $_POST['nameOnDisk'],            
            'createdBy' => $this->session->userdata('userId')
        );

        $last_insert = $this->content_model->saveContentData($data);
        echo json_encode($last_insert);
    }

    public function updatecontent(){
        // print_r($_POST);exit;
        $contentId = $this->input->post('contentId');
        $categoryId = $this->input->post('categoryId');                         
        $subCategoryId = $this->input->post('subCategoryId');        
        $title = $this->input->post('title');        
        $subTitle = $this->input->post('subTitle');
        $description = $this->input->post('description');
        $contentType = $this->input->post('contentType');
        $accessValue = $this->input->post('accessValue');
        $playOrder = $this->input->post('playOrder');        


        $config = array(
            'upload_path' => 'uploads/contentImage/',
            'allowed_types' => 'jpg|jpeg|png',
            'file_name' => rand(1,999999),
            'max_size' => 0
        );
        $this->load->library('upload', $config);
        $this->upload->initialize($config);            

        if($_FILES['contentImage']['name']!='')
        {
            if($this->upload->do_upload('contentImage'))
            {
                $dt = $this->upload->data();
                $_POST['contentImage'] = $dt['file_name'];
            }else{
                $_POST['contentImage'] = $_POST['old_contentImage'];
                $data['error']=$this->upload->display_errors();
            }
        }else{
            $_POST['contentImage'] = $_POST['old_contentImage'];
        }

        $config1 = array(
            'upload_path' => 'uploads/contentData/',
            'allowed_types' => 'mp3|mp4',
            'file_name' => rand(1,999999),
            'max_size' => 0
        );
        $this->load->library('upload', $config1);
        $this->upload->initialize($config1);            

        if($_FILES['nameOnDisk']['name']!='')
        {
            if($this->upload->do_upload('nameOnDisk'))
            {
                $dt1 = $this->upload->data();
                $_POST['nameOnDisk'] = $dt1['file_name'];
            }else{
                $_POST['nameOnDisk'] = $_POST['old_nameOnDisk'];
                $data['error']=$this->upload->display_errors();
            }
        }else{
            $_POST['nameOnDisk'] = $_POST['old_nameOnDisk'];
        }

        $data = array(
            'categoryId' => $categoryId,
            'subCategoryId' => $subCategoryId,
            'title' => $title,
            'subTitle' => $subTitle,
            'description' => $description,
            'contentType' => $contentType,
            'accessValue' => $accessValue,
            'playOrder' => $playOrder,
            'contentImage' => $_POST['contentImage'],
            'nameOnDisk' => $_POST['nameOnDisk'],            
            'updatedBy' => $this->session->userdata('userId'),
            'updatedOn' => date("Y-m-d h:i:s")
        );

        $last_update = $this->content_model->updatecontent($contentId,$data);
        echo json_encode($last_update);
    }

    public function deletecontent(){
        $contentId = $this->input->post('contentId');
        $this->content_model->deletecontentById($contentId);
        echo json_encode(array("status" => TRUE));
    }

    public function update_status(){
        $this->content_model->update_status($this->input->post('contentId'), $this->input->post('status'));
    }
    
    public function getAllSubCategory(){
        $categoryId = $_GET['categoryId'];
        $categoryList = $this->content_model->getAllSubCategory($categoryId);
        $clist = '';

        foreach($categoryList as $list){
            $clist.= '<option value="'.$list->subCategoryId.'">'.$list->subCategoryName.'</option>';
        }
        echo json_encode($clist);
    }
}

?>