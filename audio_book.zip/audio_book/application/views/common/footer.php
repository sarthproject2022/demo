</div>

<div class="rightbar-overlay"></div>
<!-- /End-bar -->

<!-- bundle -->
<script src="<?=base_url();?>assets/js/vendor.min.js"></script>
<script src="<?=base_url();?>assets/js/app.min.js"></script>

<!-- third party js -->
<script src="<?=base_url();?>assets/js/vendor/apexcharts.min.js"></script>
<script src="<?=base_url();?>assets/js/vendor/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?=base_url();?>assets/js/vendor/jquery-jvectormap-world-mill-en.js"></script>
<!-- third party js ends -->

<!-- demo app -->
<script src="<?=base_url();?>assets/js/pages/demo.dashboard.js"></script>

    <!-- quill js    For ck editor   -->
    <script src="<?=base_url();?>assets/js/vendor/quill.min.js"></script>
    <!-- Init js-->
    <script src="<?=base_url();?>assets/js/pages/demo.quilljs.js"></script>

    <!-- File upload plugin js -->
    <script src="<?=base_url();?>assets/js/vendor/dropzone.min.js"></script>
    <!-- init js -->
    <script src="<?=base_url();?>assets/js/ui/component.fileupload.js"></script>
<!-- end demo js-->

<!-- Datatables js -->
    <script src="<?=base_url();?>assets/js/vendor/jquery.dataTables.min.js"></script>
    <script src="<?=base_url();?>assets/js/vendor/dataTables.bootstrap5.js"></script>
    <script src="<?=base_url();?>assets/js/vendor/dataTables.responsive.min.js"></script>
    <script src="<?=base_url();?>assets/js/vendor/responsive.bootstrap5.min.js"></script>

    <!-- Datatable Init js -->
    <script src="<?=base_url();?>assets/js/pages/demo.datatable-init.js"></script>

    <script src="<?=base_url();?>assets/js/vendor/dataTables.select.min.js"></script>

    <!-- Buttons -->
    <script src="<?=base_url();?>assets/js/vendor/dataTables.buttons.min.js"></script>
    <script src="<?=base_url();?>assets/js/vendor/buttons.bootstrap5.min.js"></script>
    <script src="<?=base_url();?>assets/js/vendor/buttons.html5.min.js"></script>
    <script src="<?=base_url();?>assets/js/vendor/buttons.flash.min.js"></script>
    <script src="<?=base_url();?>assets/js/vendor/buttons.print.min.js"></script>
</body>
</html>