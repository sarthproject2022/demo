<style>
    .head_class{
        background-color: #343a40;
        text: #fff;
    }
</style>

<div class="content">
<!-- Topbar Start -->
    <!-- Data tables code -->
<!-- end Topbar -->

<!-- Start Content-->
<div class="container-fluid">
    
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?=base_url();?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?=base_url();?>users/addNewUser">Add User</a></li>                        
                    </ol>
                </div>
                <h4 class="page-title">List Admin Users</h4>
            </div>
        </div>
    </div>     
    <!-- end page title --> 

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">                    
                    <div class="tab-content">
                        <div class="tab-pane show active" id="multi-item-preview">
                            <table id="datatable" class="sasas table w-100 nowrap">
                                <thead>
                                    <tr class="head_class">
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Email Id</th>                                        
                                        <th>Phone</th>
                                        <th>Role</th>
                                        <th>Created On</th>
                                        <th>Status</th>                                                                                
                                        <th>Action</th>                                       
                                    </tr>
                                </thead>

                                <tbody>                                                                       
                                </tbody>

                            </table>                                          
                        </div> <!-- end preview-->
                                             
                    </div> <!-- end tab-content-->

                    
                
                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div>
    <!-- end row-->
    
</div> <!-- container -->

</div>

<script type="text/javascript">
    var table;
    var base_url = '<?php echo base_url();?>';
    
    $(document).ready(function() {
        var aUrl = base_url+"users/listData";

        table = $('#datatable').DataTable({ 
            "processing": true, 
            "serverSide": true,
            "pageLength": 50,
            "order": [], 
    
            "ajax": {
                "url": aUrl,
                "data": {   },
                "type": "POST"
            },
    
            "columnDefs": [
                { 
                    "targets": [ 0], 
                    "orderable": false,
                }
            ],           
        });
    });

    $(document).on('click','.status_checks',function()
    {
        var status=($(this).hasClass("btn btn-success")) ? '0' : '1';
        var msg=(status=='0')? 'Inactive' : 'Active';

        if(confirm('Are you sure to ' + msg + ' this user?'))
        {
            var current_element=$(this);
            var userId = $(current_element).attr('data');
            var myurl="<?php echo base_url()."users/update_status"?>";

            $.ajax({
                type:"POST",
                url:myurl,
                data:{"userId":userId,"status":status},
                success:function(data)
                {   
                    reload_table();
                }
            });
        }      
    });

    function reload_table()
    {
        table.ajax.reload(null,false); //reload datatable ajax 
    }

    function deleteUser(userId)
    {
        // console.log("hello");
        var aUrl = base_url+'users/deleteUser';
        swal({
            title: "Are you sure to delete this user?",            
            buttons: true,            
        }).then((willDelete) => {
            if(willDelete){
                $.ajax({
                    url : aUrl,
                    type: "POST",
                    dataType: "JSON",
                    data: {'userId':userId},
                    success: function(data)
                    {   
                        if(data.status){
                            swal("User deleted successfully..").then((value) => {
                                reload_table();                   
                            });                                    
                        }else{
                            swal({ title: "Unable to delete.. please try again!!", icon: "warning", buttons: true, dangerMode: true});
                        }
                        
                    },
                    error: function (jqXHR, textStatus, errorThrown)
                    {
                        swal({ title: "Unable to delete.. please try again!!", icon: "warning", buttons: true, dangerMode: true});
                    }
                });   
            }
        });
    }

</script>