<div class="content">
    <!-- Start Content-->
    <div class="container-fluid">
                            
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="<?=base_url();?>"> Home </a></li>
                            <li class="breadcrumb-item"><a href="<?=base_url();?>users">List Users</a></li>                        
                        </ol>
                    </div>
                    <h4 class="page-title"> Add New User </h4>
                </div>
            </div>
        </div>     
        <!-- end page title --> 

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">                    
                        
                        <div class="tab-content">
                            <div class="tab-pane show active" id="input-masks-preview">                                
                                <form id="addNewUser" name="addNewUser" method="POST" autocomplete="off">
                                    <div class="row g-2">
                                        <div class="mb-3 col-md-6">
                                            <label for="name" class="form-label"> Full Name </label>
                                            <input type="text" id="name" name="name" class="form-control lettersOnly" placeholder="Please enter full name">
                                            <span class="font-13 text-muted"> </span>
                                        </div>
                                        
                                        <div class="mb-3 col-md-6">
                                            <label for="phoneNo" class="form-label"> Phone No </label>
                                            <input type="tel" id="phoneNo" name="phoneNo" class="form-control numberOnly" placeholder="Please enter your phone no" maxlength="10">
                                            <span class="font-13 text-muted"> </span>
                                        </div>
                                    </div>

                                    <div class="row g-2">
                                        <div class="mb-3 col-md-6">
                                            <label for="emailId" class="form-label">Email</label>
                                            <input type="email" id="emailId" name="emailId" class="form-control" placeholder="Please enter email">
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label for="password" class="form-label">Password</label>
                                            <input type="password" id="password" name="password" class="form-control" placeholder="Please enter password">
                                        </div>
                                    </div>                                    

                                    <div class="row g-2">
                                        <!-- <div class="mb-3 col-md-6">
                                            <label for="inputCity" class="form-label">City</label>
                                            <input type="text" class="form-control" id="inputCity">
                                        </div> -->
                                        <div class="mb-3 col-md-6">
                                            <label for="roleId" class="form-label"> Role </label>
                                            <select id="roleId" name="roleId" class="form-select">                                                
                                                <option value="2"> Admin </option>
                                                <option value="3"> User </option>
                                                <option value="4"> Other </option>
                                            </select>
                                        </div>
                                        <!-- <div class="mb-3 col-md-2">
                                            <label for="inputZip" class="form-label">Zip</label>
                                            <input type="text" class="form-control" id="inputZip">
                                        </div> -->
                                    </div>

                                    <!-- <div class="mb-2">
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input" id="customCheck11">
                                            <label class="form-check-label" for="customCheck11">Check this custom checkbox</label>
                                        </div>
                                    </div> -->                                    
                                </form>
                                
                                <button type="button" id="add_user" class="btn btn-primary add_user_class">Save</button>
                                <a href="<?=base_url().'users'?>" class="btn btn-secondary">Back</a>
                                    <!-- <div class="row">
                                        <div class="col-md-6">
                                            <form id="addUser" name="addUser" method="POST" autocomplete="off">
                                                <div class="mb-3">
                                                    <label class="form-label">z</label>
                                                    <input type="text" class="form-control" data-toggle="input-mask" data-mask-format="00/00/0000" placeholder="Please">
                                                    <span class="font-13 text-muted">e.g "DD/MM/YYYY"</span>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Hour</label>
                                                    <input type="text" class="form-control" data-toggle="input-mask" data-mask-format="00:00:00">
                                                    <span class="font-13 text-muted">e.g "HH:MM:SS"</span>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Date & Hour</label>
                                                    <input type="text" class="form-control" data-toggle="input-mask" data-mask-format="00/00/0000 00:00:00">
                                                    <span class="font-13 text-muted">e.g "DD/MM/YYYY HH:MM:SS"</span>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">ZIP Code</label>
                                                    <input type="text" class="form-control" data-toggle="input-mask" data-mask-format="00000-000">
                                                    <span class="font-13 text-muted">e.g "xxxxx-xxx"</span>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Crazy Zip Code</label>
                                                    <input type="text" class="form-control" data-toggle="input-mask" data-mask-format="0-00-00-00">
                                                    <span class="font-13 text-muted">e.g "x-xx-xx-xx"</span>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Money</label>
                                                    <input type="text" class="form-control" data-toggle="input-mask" data-mask-format="000.000.000.000.000,00" data-reverse="true">
                                                    <span class="font-13 text-muted">e.g "Your money"</span>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Money 2</label>
                                                    <input type="text" class="form-control" data-toggle="input-mask" data-mask-format="#.##0,00" data-reverse="true">
                                                    <span class="font-13 text-muted">e.g "#.##0,00"</span>
                                                </div>
                                            </form>
                                        </div>

                                        <div class="col-md-6">
                                            <form action="#">
                                                <div class="mb-3">
                                                    <label class="form-label">Telephone</label>
                                                    <input type="text" class="form-control" data-toggle="input-mask" data-mask-format="0000-0000">
                                                    <span class="font-13 text-muted">e.g "xxxx-xxxx"</span>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Telephone with Code Area</label>
                                                    <input type="text" class="form-control" data-toggle="input-mask" data-mask-format="(00) 0000-0000">
                                                    <span class="font-13 text-muted">e.g "(xx) xxxx-xxxx"</span>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">US Telephone</label>
                                                    <input type="text" class="form-control" data-toggle="input-mask" data-mask-format="(000) 000-0000">
                                                    <span class="font-13 text-muted">e.g "(xxx) xxx-xxxx"</span>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">São Paulo Celphones</label>
                                                    <input type="text" class="form-control" data-toggle="input-mask" data-mask-format="(00) 00000-0000">
                                                    <span class="font-13 text-muted">e.g "(xx) xxxxx-xxxx"</span>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">CPF</label>
                                                    <input type="text" class="form-control" data-toggle="input-mask" data-mask-format="000.000.000-00" data-reverse="true">
                                                    <span class="font-13 text-muted">e.g "xxx.xxx.xxxx-xx"</span>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">CNPJ</label>
                                                    <input type="text" class="form-control" data-toggle="input-mask" data-mask-format="00.000.000/0000-00" data-reverse="true">
                                                    <span class="font-13 text-muted">e.g "xx.xxx.xxx/xxxx-xx"</span>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">IP Address</label>
                                                    <input type="text" class="form-control" data-toggle="input-mask" data-mask-format="099.099.099.099" data-reverse="true">                                            
                                                </div>
                                            </form>
                                        </div>
                                    </div> -->

                            </div> <!-- end preview-->
                                            
                        </div> <!-- end tab-content-->

                    </div> <!-- end card-body -->
                </div> <!-- end card -->
            </div> <!-- end col -->
        </div>
        <!-- end row -->

    </div>
</div>

<script>
    var base_url = "<?=base_url(); ?>";

    // $(document).ready(function() {       

    // });

    $('.add_user_class').on('click', function(){
        // console.log('hello');
        // $("#addNewUser").valid();

        var formData = new FormData($('#addNewUser')[0]); 
        var aUrl = base_url+'users/saveUser';

        $.ajax({
            url : aUrl,
            type: "POST",
            dataType: "JSON",
            data:formData,  
            processData: false,
            contentType: false, 
            success: function(data, textStatus, jqXHR){ 
                if(data > 0){
                    swal("User added successfully..").then((value) => {
                        window.location = base_url+'users';
                    });
                }else{
                    swal({
                        title: "Something goes wrong..Please try again!!",                        
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    });
                }         
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                swal({
                    title: "Please enter all fields and try again!!",
                    // text: "Check if you have entered correct data!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                });
            }                
        }); 

    });

    $( '.lettersOnly' ).keypress( function ( e ) {
        var unicode = e.charCode ? e.charCode : e.keyCode
        if ( unicode != 8 ) {
            if ((unicode > 64 && unicode < 91) || (unicode > 96 && unicode < 123) || unicode == 32 )  {  
                return true;
            }else{
                return false;
            }
        }
    });

    $( '.numberOnly' ).keypress( function ( e ) {
        var unicode = e.charCode ? e.charCode : e.keyCode
        if ( unicode != 8 ) {
            if ( unicode < 48 || unicode > 57 ){
                return false;
            }
        }
    });
</script>