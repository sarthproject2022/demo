<div class="content">
    <div class="container-fluid">
                            
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="<?=base_url();?>"> Home </a></li>
                            <li class="breadcrumb-item"><a href="<?=base_url();?>category">List Category</a></li>
                        </ol>
                    </div>
                    <h4 class="page-title"> Update Category </h4>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">                    
                        
                        <div class="tab-content">
                            <div class="tab-pane show active" id="input-masks-preview">                                
                                <form id="addNewCategory" name="addNewCategory" method="POST" autocomplete="off" enctype="multipart/form-data">
                                    <input type="hidden" id="categoryId" name="categoryId" value="<?=$categoryData->categoryId; ?>">
                                    <div class="row g-2">
                                        <div class="mb-3 col-md-6">
                                            <label for="categoryName" class="form-label"> Category Name </label>
                                            <input type="text" id="categoryName" name="categoryName" value="<?php echo ($this->input->post('categoryName')?$this->input->post('categoryName'):$categoryData->categoryName); ?>" class="form-control" placeholder="Please enter category name">
                                            <span class="font-13 text-muted"> </span>
                                        </div>
                                        
                                        <div class="mb-3 col-md-6">
                                            <label for="categoryOrder" class="form-label"> Category Order </label>
                                            <input type="tel" id="categoryOrder" name="categoryOrder" value="<?php echo ($this->input->post('categoryOrder')?$this->input->post('categoryOrder'):$categoryData->categoryOrder); ?>" class="form-control numberOnly" placeholder="Please enter display order">
                                            <span class="font-13 text-muted"> </span>
                                        </div>
                                    </div>

                                    <div class="row g-2">
                                        <div class="mb-3 col-md-6">
                                            <label for="categoryImage" class="form-label"> Category Image </label>
                                            <input type="file" id="categoryImage" name="categoryImage" value="<?php echo ($categoryData->categoryImage != "")?$categoryData->categoryImage:''; ?>" class="form-control" accept=".jpg,.jpeg,.png">
                                            <input type="hidden" name="old_categoryImage" id="old_categoryImage" value="<?php echo ($categoryData->categoryImage != "")?$categoryData->categoryImage:''; ?>" />
                                        </div>
                                        <?php if($categoryData->categoryImage){ ?>
                                            <a href="<?php echo base_url(); ?>uploads/category/<?php echo $categoryData->categoryImage; ?>" download id='categoryImage'><img src="<?php echo base_url(); ?>uploads/category/<?=$categoryData->categoryImage?>"  onerror="this.style.display='none'" width="80"/></a>
                                        <?php } ?>
                                        <p class="text-danger" id="categoryImage_validate"></p>
                                        <?php  if(form_error('categoryImage')){ echo "<span class='text-danger'>".form_error('categoryImage')."</span>";} ?>

                                    </div>                                                                                                
                                </form>
                                <br/><br/>

                                <button type="button" id="add_user" class="btn btn-primary add_category"> Update </button>
                                <a href="<?=base_url().'category'?>" class="btn btn-secondary">Back</a>                                   
                            </div>                                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    var base_url = "<?=base_url(); ?>";

    // $(document).ready(function() {       

    // });

    $('.add_category').on('click', function(){
        var formData = new FormData($('#addNewCategory')[0]); 
        var aUrl = base_url+'category/updatecategory';

        $.ajax({
            url : aUrl,
            type: "POST",
            dataType: "JSON",
            data:formData,  
            processData: false,
            contentType: false, 
            success: function(data, textStatus, jqXHR){ 
                if(data > 0){
                    swal("Category updated successfully..").then((value) => {
                        window.location = base_url+'category';
                    });
                }else{
                    swal({
                        title: "Something goes wrong..Please try again!!",                        
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    });
                }         
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                swal({
                    title: "Please enter all fields and try again!!",
                    // text: "Check if you have entered correct data!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                });
            }                
        }); 

    });

    $( '.lettersOnly' ).keypress( function ( e ) {
        var unicode = e.charCode ? e.charCode : e.keyCode
        if ( unicode != 8 ) {
            if ((unicode > 64 && unicode < 91) || (unicode > 96 && unicode < 123) || unicode == 32 )  {  
                return true;
            }else{
                return false;
            }
        }
    });

    $( '.numberOnly' ).keypress( function ( e ) {
        var unicode = e.charCode ? e.charCode : e.keyCode
        if ( unicode != 8 ) {
            if ( unicode < 48 || unicode > 57 ){
                return false;
            }
        }
    });

    var _URL = window.URL || window.webkitURL;

    $("#categoryImage").change(function(){
        var file = this.files[0];
        var size = $('#categoryImage')[0].files[0].size;
        var file_size_in_MB = size / Math.pow(1024,2);
        var validImageTypes = ["image/jpg", "image/jpeg", "image/png"];
        $("#image_name_lable").text(file);
        var ext = $('#categoryImage').val().split('.').pop().toLowerCase();
        
        if($.inArray(ext, ['jpg','jpeg','png']) == -1) 
        {
            $("#categoryImage_validate").html('Please select valid file. Only JPG, PNG and JPEG are allowed.');  
            $('#categoryImage').val('');
        }
        else if(file_size_in_MB > 2)
        {
            $("#categoryImage_validate").html('Please select file of size less than 2MB.');     
            $('#categoryImage').val('');
        }
        else{
            // var img = new Image();
            // img.onload = function() {
                
            //     if (this.width == 458 && this.height == 340) 
            //     {
            //         $("#categoryImage_validate").html('');   
            //     }else{
            //             $("#categoryImage_validate").html('Desktop Banner Dimension 458 × 340 px.');     
            //             $('#categoryImage').val('');
            //     }
                
            // };
            //     img.src = _URL.createObjectURL(file);
        }
   });  
</script>