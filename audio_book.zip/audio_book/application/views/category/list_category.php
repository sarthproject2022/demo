<style>
    .head_class{
        background-color: #343a40;
        text: #fff;
    }
</style>

<div class="content">
    <div class="container-fluid">
        
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="<?=base_url();?>">Home</a></li>
                            <li class="breadcrumb-item"><a href="<?=base_url();?>category/addNewCategory">Add category</a></li>                        
                        </ol>
                    </div>
                    <h4 class="page-title">List category</h4>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">                    
                        <div class="tab-content">
                            <div class="tab-pane show active" id="multi-item-preview">
                                <table id="datatable" class="sasas table w-100 nowrap">
                                    <thead>
                                        <tr class="head_class">
                                            <th>#</th>
                                            <th>Category Name</th>
                                            <th>Category Image</th>                                        
                                            <th>Order</th>                                        
                                            <th>Status</th>                                                                                
                                            <th>Action</th>                                       
                                        </tr>
                                    </thead>
                                    <tbody> 
                                                                                                            
                                    </tbody>
                                </table>                                          
                            </div>                                             
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    var table;
    var base_url = '<?php echo base_url();?>';
    
    $(document).ready(function() {
        var aUrl = base_url+"category/listData";

        table = $('#datatable').DataTable({ 
            "processing": true, 
            "serverSide": true,
            "pageLength": 50,
            "order": [], 
    
            "ajax": {
                "url": aUrl,
                "data": {   },
                "type": "POST"
            },
    
            "columnDefs": [
                { 
                    "targets": [ 0 ], 
                    "orderable": false,
                }
            ],           
        });
    });

    $(document).on('click','.status_checks',function()
    {
        var status=($(this).hasClass("btn btn-success")) ? '0' : '1';
        var msg=(status=='0')? 'Inactive' : 'Active';

        if(confirm('Are you sure to ' + msg + ' this category?'))
        {
            var current_element=$(this);
            var categoryId = $(current_element).attr('data');
            var myurl="<?php echo base_url()."category/update_status"?>";

            $.ajax({
                type:"POST",
                url:myurl,
                data:{"categoryId":categoryId, "status":status},
                success:function(data)
                {   
                    reload_table();
                }
            });
        }      
    });

    function reload_table()
    {
        table.ajax.reload(null,false);
    }

    function deleteCategory(categoryId)
    {
        var aUrl = base_url+'category/deleteCategory';
        swal({
            title: "Are you sure to delete this category?",            
            buttons: true,            
        }).then((willDelete) => {
            if(willDelete){
                $.ajax({
                    url : aUrl,
                    type: "POST",
                    dataType: "JSON",
                    data: {'categoryId':categoryId},
                    success: function(data)
                    {   
                        if(data.status){
                            swal("Category deleted successfully..").then((value) => {
                                reload_table();                   
                            });                                    
                        }else{
                            swal({ title: "Unable to delete.. please try again!!", icon: "warning", buttons: true, dangerMode: true});
                        }
                        
                    },
                    error: function (jqXHR, textStatus, errorThrown)
                    {
                        swal({ title: "Unable to delete.. please try again!!", icon: "warning", buttons: true, dangerMode: true});
                    }
                });   
            }
        });
    }

</script>