<div class="content">
    <!-- Start Content-->
    <div class="container-fluid">
                            
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="<?=base_url();?>"> Home </a></li>
                            <li class="breadcrumb-item"><a href="<?=base_url();?>category">List Category</a></li>
                        </ol>
                    </div>
                    <h4 class="page-title"> Add New Category </h4>
                </div>
            </div>
        </div>     
        <!-- end page title --> 

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">                    
                        
                        <div class="tab-content">
                            <div class="tab-pane show active" id="input-masks-preview">                                
                                <form id="addNewCategory" name="addNewCategory" method="POST" autocomplete="off" enctype="multipart/form-data">
                                    <div class="row g-2">
                                        <div class="mb-3 col-md-6">
                                            <label for="categoryName" class="form-label"> Category Name </label>
                                            <input type="text" id="categoryName" name="categoryName" class="form-control" placeholder="Please enter category name">
                                            <span class="font-13 text-muted"> </span>
                                        </div>
                                        
                                        <div class="mb-3 col-md-6">
                                            <label for="categoryOrder" class="form-label"> Category Order </label>
                                            <input type="tel" id="categoryOrder" name="categoryOrder" class="form-control numberOnly" placeholder="Please enter display order">
                                            <span class="font-13 text-muted"> </span>
                                        </div>
                                    </div>

                                    <div class="row g-2">
                                        <div class="mb-3 col-md-6">
                                            <label for="categoryImage" class="form-label"> Category Image </label>
                                            <input type="file" id="categoryImage" name="categoryImage" class="form-control" accept=".jpg,.jpeg,.png">
                                        </div>   
                                        <p class="text-danger" id="categoryImage_validate"></p>
                                        <?php  if(form_error('categoryImage')){ echo "<span class='text-danger'>".form_error('categoryImage')."</span>";} ?> 
                                    </div>                                                                                                
                                </form>
                                
                                <button type="button" id="add_user" class="btn btn-primary add_category">Save</button>
                                <a href="<?=base_url().'category'?>" class="btn btn-secondary">Back</a>                                   
                            </div> <!-- end preview-->
                                            
                        </div> <!-- end tab-content-->

                    </div> <!-- end card-body -->
                </div> <!-- end card -->
            </div> <!-- end col -->
        </div>
        <!-- end row -->

    </div>
</div>

<script>
    var base_url = "<?=base_url(); ?>";

    // $(document).ready(function() {       

    // });

    $('.add_category').on('click', function(){
        // console.log('hello');
        // $("#addNewCategory").valid();

        var formData = new FormData($('#addNewCategory')[0]); 
        var aUrl = base_url+'category/saveCategory';

        $.ajax({
            url : aUrl,
            type: "POST",
            dataType: "JSON",
            data:formData,  
            processData: false,
            contentType: false, 
            success: function(data, textStatus, jqXHR){ 
                if(data > 0){
                    swal("Category added successfully..").then((value) => {
                        window.location = base_url+'category';
                    });
                }else{
                    swal({
                        title: "Something goes wrong..Please try again!!",                        
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    });
                }         
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                swal({
                    title: "Please enter all fields and try again!!",
                    // text: "Check if you have entered correct data!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                });
            }                
        }); 

    });

    $( '.lettersOnly' ).keypress( function ( e ) {
        var unicode = e.charCode ? e.charCode : e.keyCode
        if ( unicode != 8 ) {
            if ((unicode > 64 && unicode < 91) || (unicode > 96 && unicode < 123) || unicode == 32 )  {  
                return true;
            }else{
                return false;
            }
        }
    });

    $( '.numberOnly' ).keypress( function ( e ) {
        var unicode = e.charCode ? e.charCode : e.keyCode
        if ( unicode != 8 ) {
            if ( unicode < 48 || unicode > 57 ){
                return false;
            }
        }
    });

    $("#categoryImage").change(function(){
        var file = this.files[0];
        var size = $('#categoryImage')[0].files[0].size;
        var file_size_in_MB = size / Math.pow(1024,2);
        var validImageTypes = ["image/jpg", "image/jpeg", "image/png"];
        $("#image_name_lable").text(file);
        var ext = $('#categoryImage').val().split('.').pop().toLowerCase();
        
        if($.inArray(ext, ['jpg','jpeg','png']) == -1) 
        {
            $("#categoryImage_validate").html('Please select valid file. Only JPG, PNG and JPEG are allowed.');  
            $('#categoryImage').val('');
        }
        else if(file_size_in_MB > 2)
        {
            $("#categoryImage_validate").html('Please select file of size less than 2MB.');     
            $('#categoryImage').val('');
        }
        else{
            // var img = new Image();
            // img.onload = function() {
                
            //     if (this.width == 458 && this.height == 340) 
            //     {
            //         $("#categoryImage_validate").html('');   
            //     }else{
            //             $("#categoryImage_validate").html('Desktop Banner Dimension 458 × 340 px.');     
            //             $('#categoryImage').val('');
            //     }
                
            // };
            //     img.src = _URL.createObjectURL(file);
        }
   });  
</script>