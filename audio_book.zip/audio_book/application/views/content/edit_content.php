<div class="content">
    <div class="container-fluid">
                            
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="<?=base_url();?>"> Home </a></li>
                            <li class="breadcrumb-item"><a href="<?=base_url();?>subcategory">List Sub Category</a></li>
                        </ol>
                    </div>
                    <h4 class="page-title"> Update Sub Category </h4>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">                    
                        
                        <div class="tab-content">
                            <div class="tab-pane show active" id="input-masks-preview">                                
                                <form id="addNewCategory" name="addNewCategory" method="POST" autocomplete="off" enctype="multipart/form-data">
                                    <input type="hidden" id="subCategoryId" name="subCategoryId" value="<?=$categoryData->subCategoryId; ?>">
                                    <div class="row g-2">
                                        <div class="mb-3 col-md-6">
                                            <label for="categoryId" class="form-label"> Category Name </label>
                                            <select id="categoryId" name="categoryId" class="form-select">                                                
                                                <option value="">--Select category--</option>
                                                <?php foreach($categoryList as $list ){ ?>                                    
                                                    <option value="<?php echo $list->categoryId; ?>"<?=$categoryData->categoryId == $list->categoryId ? ' selected="selected"' : '';?>><?php echo $list->categoryName; ?></option>
                                                <?php } ?>
                                            </select>
                                            <span class="font-13 text-muted"> </span>
                                        </div>

                                        <div class="mb-3 col-md-6">
                                            <label for="subCategoryName" class="form-label"> Sub Category Name </label>
                                            <input type="text" id="subCategoryName" name="subCategoryName" value="<?php echo ($this->input->post('subCategoryName')?$this->input->post('subCategoryName'):$categoryData->subCategoryName); ?>" class="form-control" placeholder="Please enter category name">
                                            <span class="font-13 text-muted"> </span>
                                        </div>                                                                        
                                    </div>

                                    <div class="row g-2">
                                        <div class="mb-3 col-md-6">
                                            <label for="subCategoryOrder" class="form-label"> Sub Category Order </label>
                                            <input type="tel" id="subCategoryOrder" name="subCategoryOrder" value="<?php echo ($this->input->post('subCategoryOrder')?$this->input->post('subCategoryOrder'):$categoryData->subCategoryOrder); ?>" class="form-control numberOnly" placeholder="Please enter display order">
                                            <span class="font-13 text-muted"> </span>
                                        </div>

                                        <div class="mb-3 col-md-6">
                                            <label for="subCategoryImage" class="form-label"> Sub Category Image </label>
                                            <input type="file" id="subCategoryImage" name="subCategoryImage" value="<?php echo ($categoryData->subCategoryImage != "")?$categoryData->subCategoryImage:''; ?>" class="form-control" accept=".jpg,.jpeg,.png">
                                            <input type="hidden" name="old_subCategoryImage" id="old_subCategoryImage" value="<?php echo ($categoryData->subCategoryImage != "")?$categoryData->subCategoryImage:''; ?>" />
                                            <?php if($categoryData->subCategoryImage){ ?>
                                            <a href="<?php echo base_url(); ?>uploads/subcategory/<?php echo $categoryData->subCategoryImage; ?>" download id='subCategoryImage'><img src="<?php echo base_url(); ?>uploads/subcategory/<?=$categoryData->subCategoryImage?>"  onerror="this.style.display='none'" width="80"/></a>
                                            <?php } ?>
                                            <p class="text-danger" id="subCategoryImage_validate"></p>
                                            <?php  if(form_error('subCategoryImage')){ echo "<span class='text-danger'>".form_error('subCategoryImage')."</span>";} ?>
                                        </div>
                                    </div>                                                                                                
                                </form>                                

                                <button type="button" id="add_user" class="btn btn-primary add_category"> Update </button>
                                <a href="<?=base_url().'subcategory'?>" class="btn btn-secondary">Back</a>                                   
                            </div>                                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    var base_url = "<?=base_url(); ?>";

    // $(document).ready(function() {       

    // });

    $('.add_category').on('click', function(){
        var formData = new FormData($('#addNewCategory')[0]); 
        var aUrl = base_url+'subcategory/updatecategory';

        $.ajax({
            url : aUrl,
            type: "POST",
            dataType: "JSON",
            data:formData,  
            processData: false,
            contentType: false, 
            success: function(data, textStatus, jqXHR){ 
                if(data > 0){
                    swal("Sub category updated successfully..").then((value) => {
                        window.location = base_url+'subcategory';
                    });
                }else{
                    swal({
                        title: "Something goes wrong..Please try again!!",                        
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    });
                }         
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                swal({
                    title: "Please enter all fields and try again!!",
                    // text: "Check if you have entered correct data!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                });
            }                
        }); 

    });

    $( '.lettersOnly' ).keypress( function ( e ) {
        var unicode = e.charCode ? e.charCode : e.keyCode
        if ( unicode != 8 ) {
            if ((unicode > 64 && unicode < 91) || (unicode > 96 && unicode < 123) || unicode == 32 )  {  
                return true;
            }else{
                return false;
            }
        }
    });

    $( '.numberOnly' ).keypress( function ( e ) {
        var unicode = e.charCode ? e.charCode : e.keyCode
        if ( unicode != 8 ) {
            if ( unicode < 48 || unicode > 57 ){
                return false;
            }
        }
    });

    var _URL = window.URL || window.webkitURL;

    $("#subCategoryImage").change(function(){
        var file = this.files[0];
        var size = $('#subCategoryImage')[0].files[0].size;
        var file_size_in_MB = size / Math.pow(1024,2);
        var validImageTypes = ["image/jpg", "image/jpeg", "image/png"];
        $("#image_name_lable").text(file);
        var ext = $('#subCategoryImage').val().split('.').pop().toLowerCase();
        
        if($.inArray(ext, ['jpg','jpeg','png']) == -1) 
        {
            $("#subCategoryImage_validate").html('Please select valid file. Only JPG, PNG and JPEG are allowed.');  
            $('#subCategoryImage').val('');
        }
        else if(file_size_in_MB > 2)
        {
            $("#subCategoryImage_validate").html('Please select file of size less than 2MB.');     
            $('#subCategoryImage').val('');
        }
        else{
            // var img = new Image();
            // img.onload = function() {
                
            //     if (this.width == 458 && this.height == 340) 
            //     {
            //         $("#subCategoryImage_validate").html('');   
            //     }else{
            //             $("#subCategoryImage_validate").html('Desktop Banner Dimension 458 × 340 px.');     
            //             $('#subCategoryImage').val('');
            //     }
                
            // };
            //     img.src = _URL.createObjectURL(file);
        }
   });  
</script>