<div class="content">
    <!-- Start Content-->
    <div class="container-fluid">
                            
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="<?=base_url();?>"> Home </a></li>
                            <li class="breadcrumb-item"><a href="<?=base_url();?>content">List Content</a></li>
                        </ol>
                    </div>
                    <h4 class="page-title"> Add content </h4>
                </div>
            </div>
        </div>     
        <!-- end page title --> 

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">                    
                        
                        <div class="tab-content">
                            <div class="tab-pane show active" id="input-masks-preview">                                
                                <form id="addNewContent" name="addNewContent" method="POST" autocomplete="off" enctype="multipart/form-data">
                                    <div class="row g-2">
                                        <div class="mb-3 col-md-6">
                                            <label for="categoryId" class="form-label"> Category </label>
                                            <select id="categoryId" name="categoryId" class="form-select">                                                
                                                <option value="">--Select category--</option>
                                                <?php foreach($categoryList as $list ){ ?>                                    
                                                    <option value="<?php echo $list->categoryId; ?>"><?php echo $list->categoryName; ?></option>                                    
                                                <?php } ?>
                                            </select>                                            
                                        </div>

                                        <div class="mb-3 col-md-6">
                                            <label for="subCategoryId" class="form-label"> Sub Category </label>
                                            <select id="subCategoryId" name="subCategoryId" class="form-select">
                                                <option value="">--Select sub category--</option>                                                
                                            </select>                                            
                                        </div>                                                                                                         
                                    </div>

                                    <div class="row g-2">
                                        <div class="mb-3 col-md-6">
                                            <label for="title" class="form-label"> Title </label>
                                            <input type="text" id="title" name="title" class="form-control" placeholder="Please enter title">
                                            <span class="font-13 text-muted"> </span>
                                        </div>   

                                        <div class="mb-3 col-md-6">
                                            <label for="subTitle" class="form-label"> Sub Title </label>
                                            <input type="tel" id="subTitle" name="subTitle" class="form-control" placeholder="Please enter sub title">
                                            <span class="font-13 text-muted"> </span>
                                        </div>                                        
                                    </div> 
                                    
                                    <div class="row g-2">
                                        <!-- <div class="mb-3 col-md-6"> -->
                                            <label for="description" class="form-label"> Description </label>                                            
                                            <textarea class="form-control" id="description" name="description" placeholder="Please enter description" rows="3"></textarea>
                                            <span class="font-13 text-muted"> </span>
                                        <!-- </div>                                                                                 -->
                                    </div> 

                                    <div class="row g-2">
                                        <div class="mb-3 col-md-6">
                                            <label for="contentType" class="form-label"> Content Type </label>
                                            <select id="contentType" name="contentType" class="form-select">                                                
                                                <option value="1"> Audio File </option>
                                                <option value="2"> Document </option>                         
                                                <option value="3"> Video File </option>                         
                                            </select>                                            
                                        </div>  
                                        
                                        <div class="mb-3 col-md-6">
                                            <label for="accessValue" class="form-label"> Subscription </label>
                                            <select id="accessValue" name="accessValue" class="form-select">                                                
                                                <option value="1"> Free </option>
                                                <option value="2"> Basic </option>                         
                                                <option value="3"> Prime </option>                         
                                            </select>                                            
                                        </div>  
                                    </div> 
                                    
                                    <div class="row g-2">
                                        <div class="mb-3 col-md-6">
                                            <label for="playOrder" class="form-label"> Content Playing Order </label>
                                            <input type="text" id="playOrder" name="playOrder" class="form-control numberOnly" placeholder="Please enter order">
                                            <span class="font-13 text-muted"> </span>
                                        </div>                                                                              
                                    </div>  
                                    
                                    <div class="row g-2"> 
                                        <div class="mb-3 col-md-6">
                                            <label for="contentImage" class="form-label"> Content Image </label>
                                            <input type="file" id="contentImage" name="contentImage" class="form-control" accept=".jpg,.jpeg,.png">
                                            <p class="text-danger" id="contentImage_validate"></p>
                                        </div> 
                                        
                                        <?php  if(form_error('contentImage')){ echo "<span class='text-danger'>".form_error('contentImage')."</span>";} ?>                                      

                                        <div class="mb-3 col-md-6">
                                            <label for="nameOnDisk" class="form-label"> Content File </label>
                                            <input type="file" id="nameOnDisk" name="nameOnDisk" class="form-control" accept=".mp3,.mp4">
                                        </div>                                        
                                    </div> 
                                </form>
                                
                                <button type="button" id="add_content" class="btn btn-primary add_content_class">Save</button>
                                <a href="<?=base_url().'content'?>" class="btn btn-secondary">Back</a>                                   
                            </div>                                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    var base_url = "<?=base_url(); ?>";

    // $(document).ready(function() {       

    // });
    $('#categoryId').on('change', function(){     
        var aUrl = base_url+'content/getAllSubCategory';
        var categoryId = $('#categoryId').val();

        $.ajax({
            url : aUrl,
            type: "GET",
            dataType: "JSON",
            data: {'categoryId':categoryId},
            success: function(data){ 
                $('#subCategoryId').html(data);
            }
        });
    });
    
    $('.add_content_class').on('click', function(){     
        var formData = new FormData($('#addNewContent')[0]); 
        var aUrl = base_url+'content/saveContentData';

        $.ajax({
            url : aUrl,
            type: "POST",
            dataType: "JSON",
            data:formData,  
            processData: false,
            contentType: false, 
            success: function(data, textStatus, jqXHR){ 
                if(data > 0){
                    swal(" Content added successfully..").then((value) => {
                        window.location = base_url+'content';
                    });
                }else{
                    swal({
                        title: "Something goes wrong..Please try again!!",                        
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    });
                }         
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                swal({
                    title: "Please enter all fields and try again!!",
                    // text: "Check if you have entered correct data!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                });
            }                
        }); 

    });

    $( '.lettersOnly' ).keypress( function ( e ) {
        var unicode = e.charCode ? e.charCode : e.keyCode
        if ( unicode != 8 ) {
            if ((unicode > 64 && unicode < 91) || (unicode > 96 && unicode < 123) || unicode == 32 )  {  
                return true;
            }else{
                return false;
            }
        }
    });

    $( '.numberOnly' ).keypress( function ( e ) {
        var unicode = e.charCode ? e.charCode : e.keyCode
        if ( unicode != 8 ) {
            if ( unicode < 48 || unicode > 57 ){
                return false;
            }
        }
    });

    $("#contentImage").change(function(){
        var file = this.files[0];
        var size = $('#contentImage')[0].files[0].size;
        var file_size_in_MB = size / Math.pow(1024,2);
        var validImageTypes = ["image/jpg", "image/jpeg", "image/png"];
        $("#image_name_lable").text(file);
        var ext = $('#contentImage').val().split('.').pop().toLowerCase();
        
        if($.inArray(ext, ['jpg','jpeg','png']) == -1) 
        {
            $("#contentImage_validate").html('Please select valid file. Only JPG, PNG and JPEG are allowed.');  
            $('#contentImage').val('');
        }
        else if(file_size_in_MB > 2)
        {
            $("#contentImage_validate").html('Please select file of size less than 2MB.');     
            $('#contentImage').val('');
        }
        else{
            // var img = new Image();
            // img.onload = function() {
                
            //     if (this.width == 458 && this.height == 340) 
            //     {
            //         $("#contentImage_validate").html('');   
            //     }else{
            //             $("#contentImage_validate").html('Desktop Banner Dimension 458 × 340 px.');     
            //             $('#contentImage').val('');
            //     }
                
            // };
            //     img.src = _URL.createObjectURL(file);
        }
   });  
</script>