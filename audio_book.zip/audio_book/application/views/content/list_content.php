<style>
    .head_class{
        background-color: #343a40;
        text: #fff;
    }
</style>

<div class="content">
    <div class="container-fluid">
        
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="<?=base_url();?>">Home</a></li>
                            <li class="breadcrumb-item"><a href="<?=base_url();?>content/addcontent">Add content</a></li>
                        </ol>
                    </div>
                    <h4 class="page-title">List Content</h4>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">                    
                        <div class="tab-content">
                            <div class="tab-pane show active" id="multi-item-preview">
                                <table id="datatable" class="sasas table w-100 nowrap">
                                    <thead>
                                        <tr class="head_class">
                                            <th>#</th>
                                            <th>Category</th>
                                            <th>Sub Category</th>
                                            <th>Title</th>                                        
                                            <th>Sub Title</th>                                        
                                            <th> Content Type </th>                                            
                                            <th> Subscription </th>
                                            <th> Playing order </th>
                                            <th> Image </th>
                                            <th> Content </th>
                                            <th>Status</th>                                                                                
                                            <th>Action</th>                                       
                                        </tr>
                                    </thead>
                                    <tbody> 
                                                                                                            
                                    </tbody>
                                </table>                                          
                            </div>                                             
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    var table;
    var base_url = '<?php echo base_url();?>';
    
    $(document).ready(function() {
        var aUrl = base_url+"content/listData";

        table = $('#datatable').DataTable({ 
            "processing": true, 
            "serverSide": true,
            "pageLength": 100,
            "order": [], 
    
            "ajax": {
                "url": aUrl,
                "data": {   },
                "type": "POST"
            },
    
            "columnDefs": [
                { 
                    "targets": [ 0 ], 
                    "orderable": false,
                }
            ],           
        });
    });

    $(document).on('click','.status_checks',function()
    {
        var status=($(this).hasClass("btn btn-success")) ? '0' : '1';
        var msg=(status=='0')? 'Inactive' : 'Active';

        if(confirm('Are you sure to ' + msg + ' this content?'))
        {
            var current_element=$(this);
            var contentId = $(current_element).attr('data');
            var myurl="<?php echo base_url()."content/update_status"?>";

            $.ajax({
                type:"POST",
                url:myurl,
                data:{"contentId":contentId, "status":status},
                success:function(data)
                {   
                    reload_table();
                }
            });
        }      
    });

    function reload_table()
    {
        table.ajax.reload(null,false);
    }

    function deletecontent(contentId)
    {
        var aUrl = base_url+'content/deletecontent';
        swal({
            title: "Are you sure to delete this content?",            
            buttons: true,            
        }).then((willDelete) => {
            if(willDelete){
                $.ajax({
                    url : aUrl,
                    type: "POST",
                    dataType: "JSON",
                    data: {'contentId':contentId},
                    success: function(data)
                    {   
                        if(data.status){
                            swal("Content deleted successfully..").then((value) => {
                                reload_table();                   
                            });                                    
                        }else{
                            swal({ title: "Unable to delete.. please try again!!", icon: "warning", buttons: true, dangerMode: true});
                        }
                        
                    },
                    error: function (jqXHR, textStatus, errorThrown)
                    {
                        swal({ title: "Unable to delete.. please try again!!", icon: "warning", buttons: true, dangerMode: true});
                    }
                });   
            }
        });
    }

</script>